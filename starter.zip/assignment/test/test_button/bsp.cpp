#include "bsp.h"

void bsp_pin_mode(uint8_t pin, uint8_t mode)
{
}

int bsp_digital_read(uint8_t pin)
{
}