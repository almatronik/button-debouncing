#include "bsp.h"
#include "button.h"

#define SAMPLES (5U)

void button_init(uint8_t pin)
{
}

void button_update_state(void)
{
}

uint8_t button_get_state(void)
{
}